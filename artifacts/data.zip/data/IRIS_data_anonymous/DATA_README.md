# IRIS ARR Data Archive

This anonymized data archive contains non-sensitive inputs and aggregate summaries for ARR review.

Included:
- `data/behavior_datasets/`: the redacted 105-item behavior-level evaluation panel used for review.
- `data/splits/`: pilot and full105 behavior ID lists.
- `data/full105/`: generated supplementary input assets for FormalLogic and low-resource-language probes.
- `data/pilot/`: small pilot assets for smoke reproduction.
- `results/`: aggregate rerun summaries and low-resource back-translation control summaries.

Excluded:
- Complete model generations and raw completion files.
- Raw judge JSON files and request/response metadata logs.
- Per-annotator state files and unrestricted annotation dumps.
- Full external benchmark inventories, Stage-II working CSVs, and operational jailbreak scaffolds beyond the redacted behavior-level assets needed for review.
- Temporary rerun logs, exploratory archives, and private writing materials.

These exclusions follow the paper's redaction and controlled-access policy for operational harmful prompts, complete jailbreak scaffolds, complete model outputs, and per-annotator records.

Redaction note: this ARR data archive replaces benchmark-provided person-like names, emails, phone numbers, social handles, school names, employer names, and city names with bracketed placeholders where they appear in released behavior text or generated supplementary input assets. The unredacted audit materials are retained outside this unrestricted archive under the controlled-access policy described in the paper.
