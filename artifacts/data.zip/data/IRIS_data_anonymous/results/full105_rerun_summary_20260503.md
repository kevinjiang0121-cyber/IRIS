# Full105 Rerun Summary (2026-05-03)

- Step 2: 5 methods x 6 models completed with `--thinking_mode off`.
- Step 3 for ArtPrompt / FormalLogic / CaesarCipher uses `judge_prompts.yaml` template `1` (v2.2 English).
- Step 3 for LowResourceLang uses `judge_prompts_v22_lrl.yaml` template `9` (v2.2-compatible low-resource adapter).

## ArtPrompt / full105_cards

| Model | Step2 | Step3 | UR | combined_ASR | Empty | Note |
|---|---|---:|---:|---:|---:|---|
| `gpt-4o-2024-11-20` | `done` | `done` | 0.4667 | 0.0571 | 0.0000 | - |
| `claude-sonnet-4.5` | `done` | `done` | 0.4571 | 0.0190 | 0.5429 | high_empty_response |
| `claude-opus-4.5` | `done` | `done` | 0.2286 | 0.0000 | 0.6952 | high_empty_response |
| `gemini_3_flash_preview` | `done` | `done` | 0.8095 | 0.2381 | 0.0000 | - |
| `qwen3-max` | `done` | `done` | 0.8667 | 0.0762 | 0.0190 | - |
| `deepseek-v3.2` | `done` | `done` | 0.2571 | 0.0571 | 0.0000 | - |

## FormalLogic / full105

| Model | Step2 | Step3 | UR | combined_ASR | Empty | Note |
|---|---|---:|---:|---:|---:|---|
| `gpt-4o-2024-11-20` | `done` | `done` | 0.9619 | 0.5238 | 0.0000 | - |
| `claude-sonnet-4.5` | `done` | `done` | 0.5810 | 0.1810 | 0.4000 | - |
| `claude-opus-4.5` | `done` | `done` | 0.4190 | 0.0667 | 0.5714 | high_empty_response |
| `gemini_3_flash_preview` | `done` | `done` | 1.0000 | 0.4952 | 0.0000 | - |
| `qwen3-max` | `done` | `done` | 1.0000 | 0.2476 | 0.0000 | - |
| `deepseek-v3.2` | `done` | `done` | 0.9429 | 0.5619 | 0.0476 | - |

## CaesarCipher / full105_control

| Model | Step2 | Step3 | UR | combined_ASR | Empty | Note |
|---|---|---:|---:|---:|---:|---|
| `gpt-4o-2024-11-20` | `done` | `done` | 0.9905 | 0.0286 | 0.0000 | - |
| `claude-sonnet-4.5` | `done` | `done` | 0.0000 | 0.0000 | 1.0000 | invalid_empty_response |
| `claude-opus-4.5` | `done` | `done` | 0.0000 | 0.0000 | 1.0000 | invalid_empty_response |
| `gemini_3_flash_preview` | `done` | `done` | 1.0000 | 0.0190 | 0.0000 | - |
| `qwen3-max` | `done` | `done` | 1.0000 | 0.0000 | 0.0000 | - |
| `deepseek-v3.2` | `done` | `done` | 0.7238 | 0.0571 | 0.0381 | - |

## LowResourceLang / full105_zulu

| Model | Step2 | Step3 | UR | combined_ASR | Empty | Note |
|---|---|---:|---:|---:|---:|---|
| `gpt-4o-2024-11-20` | `done` | `done` | 0.5143 | 0.0381 | 0.0000 | - |
| `claude-sonnet-4.5` | `done` | `done` | 0.8857 | 0.2667 | 0.0095 | - |
| `claude-opus-4.5` | `done` | `done` | 0.9238 | 0.0762 | 0.0476 | - |
| `gemini_3_flash_preview` | `done` | `done` | 0.9905 | 0.1810 | 0.0000 | - |
| `qwen3-max` | `done` | `done` | 0.8190 | 0.3143 | 0.0000 | - |
| `deepseek-v3.2` | `done` | `done` | 0.8952 | 0.1524 | 0.0381 | - |

## LowResourceLang / full105_yoruba

| Model | Step2 | Step3 | UR | combined_ASR | Empty | Note |
|---|---|---:|---:|---:|---:|---|
| `gpt-4o-2024-11-20` | `done` | `done` | 0.4190 | 0.1238 | 0.0000 | - |
| `claude-sonnet-4.5` | `done` | `done` | 0.8762 | 0.4190 | 0.0190 | - |
| `claude-opus-4.5` | `done` | `done` | 0.9429 | 0.1048 | 0.0286 | - |
| `gemini_3_flash_preview` | `done` | `done` | 0.9810 | 0.2095 | 0.0000 | - |
| `qwen3-max` | `done` | `done` | 0.8667 | 0.5238 | 0.0000 | - |
| `deepseek-v3.2` | `done` | `done` | 0.8000 | 0.4762 | 0.1143 | - |
