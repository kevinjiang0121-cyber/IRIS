# Data archive for the current submission

## Starting point
This archive retains every file in the locally archived May-cycle data.zip, byte-for-byte and at its original relative path. The May inputs, pilot assets, split lists, construction notes, and result summaries remain available.

Start with this README for the current submission. DATA_README.md and MANIFEST.txt describe the original May package; MANIFEST_SHA256.json indexes this complete updated archive.

## Current result tables
Use results/current_submission/ for the current manuscript. The older results outside that directory retain their original metric names and values.

- headline_metrics.csv: 60 model-condition cells, six models and ten conditions (EN, TOK, Zulu, Yoruba, Caesar, FormalLogic, ArtPrompt, T1, T2, T3). n=105 per cell. operative_UR is P(IR=2 and IS=NA), recognition_rate is P(IR=2), and ASR is P(SO>=2). Shift and B report response-frame changes and blocked/empty outputs. All rates are percentages; n, operative_count, and harm_outside_operative are counts. These are the reviewed manuscript aggregates.
- operative_UR_intervals.csv: marginal 95% bootstrap intervals for the same cells, in percent; 10,000 resamples, seed 20260930.
- t1_t3.csv: matched T1-to-T3 contingency counts. a_rate and b_rate are the T1 and T3 percentages; delta_pp and ci_low/ci_high are percentage points. p_exact is the two-sided exact McNemar p-value; p_holm adjusts across six models. Paired intervals use 10,000 resamples, seed 20261005.
- iaa.csv: aggregate independent-reader agreement for operative UR and ASR. n00/n01/n10/n11 count A1/A2 binary outcomes; agreement is a fraction and kappa is unitless. a_rate/b_rate are reader percentages; strict/permissive are intersection/union percentages.
- paired_reading.csv: judge, A1, A2, and intersection/union endpoints in percent, computed from independent labels before adjudication.
- backtranslation_control.csv: the original direct-LRL versus English-backtranslation control, copied from the May archive. Rate and delta columns are fractions; ur denotes recognition alone. Both conditions use the original automated judgments.

## Metric and language naming
The May ur field denotes recognition alone. It is distinct from the current operative_UR joint event. Existing input columns keep TK and EO; current manuscript labels are TOK and EPO. EN corresponds to the former Direct condition.

## Data scope
The original redacted inputs are retained unchanged. Aggregate human-review statistics are included; item-level human annotation files, full model responses, raw judge records, and pipeline code are not part of this data archive. Frozen executed prompts and software are available in the separate anonymous experiment repository. The redacted behavior assets serve data inspection and retain the May package's source attributions and redactions.
